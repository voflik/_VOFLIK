# CC16 Workshop Code Snippets for "Automated Testing in ServiceNow: Let the Robots Do It"
This repository contains the code snippets needed to complete the CreatorCon workshop **Automated Testing in ServiceNow: Let the Robots Do It**. 

To copy source code, either direct link to the snippet from the Workshop guide, or else locate the snippet by browsing in this repository and click **Raw**. Select the entire script in Raw form and then copy/paste the script to where it needs to go.
