# CC16 Workshop Code Snippets for "Build custom services the right way with Scripted REST APIs"
This repository contains the code snippets needed to complete the CreatorCon workshop **Build custom services the right way with Scripted REST APIs**.

To copy source code, either direct link to the snippet from the Workshop guide, or else locate the snippet by browsing in this repository and click **Raw**. Select the entire script in Raw form and then copy/paste the script to where it needs to go.
