(function process(/*RESTAPIRequest*/ request, /*RESTAPIResponse*/ response) {	
    return "Hello, world!";
})(request, response);
